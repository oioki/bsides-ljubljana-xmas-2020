<?php
session_start();

// Some idiots on StackOverflow said this was bad code or something.
// Clearly they have never used a proxy...
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

// Only allow access from the local network

if (! (substr( $ip, 0, 4 ) === "127.") ) {
    header("Location: /");
    echo "Access Denied!";
    die();
}

if( isset($_POST["save_details"]) ) {
    unset($_POST["save_details"]);

    foreach ( $_POST as $key => $value ) {
        $_SESSION[$key] = $value;
    }

}
?>

<!DOCTYPE html>
<html>
<head>
    <title> The North Pole | Admin Dashboard </title>
    <link rel="stylesheet" href="css/bootstrap.css" />
    <script src="js/bootstrap.js"></script>

    <style>
        #main {
            max-width:900px;
            width:100;
            margin: auto;
            margin-top: 50px;
            box-shadow: 5px 10px 18px #000;
            padding: 25px 15px;
            border-radius: 8px;
            background-color: white;
        }
        body {
            background-image: url("images/background.jpg");

        }
    </style>
</head>
<body>
<section id="main">
    <h1>Elf details</h1>
    <form method="POST" action="">
        <div class="form-group">
            <input type="text" name="name" value="<?= htmlentities($_SESSION["name"] ?? ""); ?>" />
        </div>
        <div class="form-group">
            <input type="text" name="lastname" value="<?= htmlentities($_SESSION["lastname"] ?? ""); ?>" /><br>
        </div>
        
        <div class="form-group">
        <input type="text" name="age" value="<?= htmlentities($_SESSION["age"] ?? ""); ?>" /><br>
        </div>

        <input type="submit" name="save_details" value="Save Session" />
    </form>
</section>
</body>
</html>