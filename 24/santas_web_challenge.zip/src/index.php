<?php
session_start();

$names = ["Tickle", "Jolly", "Buddy", "Eddie", "Jingle", "Candy", "Ernie", "Cookie", "Happy", "Frosty", "Elfie", "Tinsel", "Elvis", "Twinkle", "Berry", "Buster", "Charlie", "Alfie", "Freddy", "Merry", "North", "Holly", "Noel", "Max", "Tiny", "Sparky"];
$lastnames = ["McSnowflake", "Humberdink", "McFluff", "Sparklepants", "Twinkletoes", "McJingles", "Stripytights", "Gumdrop", "Tinselbottom"];
$street_names = ["Iglis", "Thermia", "Chill", "Hiver", "Moonchill", "Barehost", "Avalvault", "Sleetstrand", "Thawband", "Cleargrave"]; 
$gifts = ["Yoyo", "Bouncy Ball", "Compass", "Guitar", "Football", "Gloves", "Scarf", "Marbles", "Pokemon cards", "Monopoly", "Magic wand", "Laser"];


if (! isset($_SESSION["elf_id"]) ) {
    $_SESSION["elf_id"] = rand(1000,2000);

    $_SESSION["name"] = $names[rand(0, count($names) - 1)];
    $_SESSION["lastname"] = $lastnames[rand(0, count($lastnames) - 1)];

    $_SESSION["age"] = rand(200,300); // Elves are old... maybe they should retire?

    system("echo > /tmp/elf_" . $_SESSION["elf_id"]);
    for ($i = 0; $i < 3; $i++) {
        $delivery_address = rand(1, 99) . " " . $street_names[rand(0, count($street_names) - 1)] . " " . ["street", "avenue"][rand(0, 1)];
        $gift = $gifts[rand(0, count($gifts) - 1)];

        // Is this how you generate a weighted random value??? I guess so 
        $shipping_method = ["normal", "normal", "normal", "Polar Express Shipping"][rand(0, 3)];

        system("echo '<tr><td>$gift</td><td>$delivery_address</td><td>$shipping_method</td></tr>' >> /tmp/elf_" . $_SESSION["elf_id"]);
    }
}


$deliveries = file_get_contents("/tmp/elf_" . $_SESSION["elf_id"]);


/*
$flag = file_get_contents("/tmp/flag.txt");

echo $flag; // :)
*/

?>

<!DOCTYPE html>
<html>
<head>
    <title> The North Pole | Delivery Dashboard </title>
    <link rel="stylesheet" href="css/bootstrap.css" />
    <script src="js/bootstrap.js"></script>

    <style>
        #main {
            max-width:900px;
            width:100;
            margin: auto;
            margin-top: 50px;
            box-shadow: 5px 10px 18px #000;
            padding: 25px 15px;
            border-radius: 8px;
            background-color: white;
        }
        body {
            background-image: url("images/background.jpg");

        }
    </style>
</head>
<body>
<section id="main">

<h1>Greetings <?= htmlentities($_SESSION["name"] . " " . $_SESSION["lastname"]); ?>!</h1>

<h1>Welcome to The North Pole's Shipping & Logistics center</h1>

<p>Below you can find all your outstanding deliveries. Please finish all Polar Express Shipping &copy; deliveries before Christmas.<br>
As for the regular deliveries, you don't need to worry to much about making them in time :D It's not like children can ask for refunds for their gifts</p>

<table class="table">
    <tr>
        <th>Gift</th>
        <th>Address</th>
        <th>Shipping Method</th>
    </tr>
    <?= $deliveries; ?>
</table>

</section>

</body>
</html>